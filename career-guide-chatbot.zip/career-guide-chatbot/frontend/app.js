// Backend API URL
const API_URL = "http://127.0.0.1:8000";

// Demo user (replace later with real authentication)
let userId = 1;
let sessionId = null;

// DOM Elements
const messagesContainer = document.getElementById("messages");
const userInput = document.getElementById("userInput");
const sendBtn = document.getElementById("sendBtn");

// Add message to UI
function addMessage(role, content) {
    const messageDiv = document.createElement("div");
    messageDiv.classList.add("message");
    messageDiv.classList.add(role === "user" ? "user-message" : "assistant-message");

    const bubble = document.createElement("div");
    bubble.classList.add("message-bubble");
    bubble.innerText = content;

    messageDiv.appendChild(bubble);
    messagesContainer.appendChild(messageDiv);

    // Auto scroll
    messagesContainer.scrollTop = messagesContainer.scrollHeight;
}

// Send message to backend
async function sendMessage() {
    const text = userInput.value.trim();
    if (!text) return;

    // Show user message immediately
    addMessage("user", text);
    userInput.value = "";

    try {
        const response = await fetch(`${API_URL}/chat/`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                user_id: userId,
                message: text,
                session_id: sessionId
            })
        });

        if (!response.ok) {
            console.error("Backend error:", response.status);
            addMessage("assistant", "Server error. Please try again.");
            return;
        }

        const data = await response.json();
        console.log("Backend response:", data);

        if (data.reply) {
            sessionId = data.session_id;
            addMessage("assistant", data.reply);
        } else {
            addMessage("assistant", "No response received.");
        }

    } catch (error) {
        console.error("Connection error:", error);
        addMessage("assistant", "Unable to connect to server.");
    }
}

// Event listeners
sendBtn.addEventListener("click", sendMessage);

userInput.addEventListener("keypress", function (e) {
    if (e.key === "Enter") {
        sendMessage();
    }
});
