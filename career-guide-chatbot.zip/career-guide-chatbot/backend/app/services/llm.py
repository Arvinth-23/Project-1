from openai import OpenAI
from app.config import settings

client = OpenAI(api_key=settings.openai_api_key)

async def get_chat_response(conversation, user_context=""):

    system_prompt = f"""
You are a career guidance advisor for college students.
{user_context}
Provide helpful, accurate, and encouraging advice.
Be concise but informative.
"""

    messages = [{"role": "system", "content": system_prompt}] + conversation

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            temperature=0.7,
        )

        return response.choices[0].message.content

    except Exception as e:
        print("OPENAI ERROR:", e)
        return f"Error from OpenAI: {str(e)}"
