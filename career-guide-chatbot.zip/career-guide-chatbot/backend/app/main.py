from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import chat, user
from app.database import engine
from app.models import Base

# Create FastAPI app
app = FastAPI(title="Career Guide Chatbot")

# ---------------- CORS CONFIGURATION ----------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://127.0.0.1:5500",
        "http://localhost:5500",
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------- INCLUDE ROUTERS ----------------
app.include_router(chat.router)
app.include_router(user.router)

# ---------------- CREATE TABLES ----------------
async def init_db():
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

@app.on_event("startup")
async def on_startup():
    await init_db()

# ---------------- ROOT TEST ROUTE ----------------
@app.get("/")
async def root():
    return {"message": "Career Guide Chatbot Backend Running"}
